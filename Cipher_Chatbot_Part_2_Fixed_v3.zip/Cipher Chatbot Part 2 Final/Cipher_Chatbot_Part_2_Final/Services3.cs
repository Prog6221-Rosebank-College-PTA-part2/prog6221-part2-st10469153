using System;
using System.Collections.Generic;
using CyberSecurityChatBot.Models;
using CyberSecurityChatBot.Services;

namespace CyberSecurityChatBot.Services
{
    public class ResponseService
    {
        private readonly ChatMemory memory;
        private readonly Random random = new Random();
        private readonly Dictionary<string, List<string>> keywordResponses;

        public ResponseService(ChatMemory memory)
        {
            this.memory = memory;

            keywordResponses = new Dictionary<string, List<string>>()
            {
                {
                    "purpose",
                    new List<string>()
                    {
                        "I am Cipher\n" +
                        "I am a chatbot made to educate and provide some insight to cybersecurity and tech-related security measures.\n" +
                        "I was made in 2026 as an attempt to counter the increasing number of cyberattacks that were taking place.\n" +
                        "Since most people are not as aware about the potential dangers and risks that come with technology, there are people who exploit that to their own benefit.\n" +
                        "So if you are eager to learn, go ahead and ask any cybersecurity-related questions you may be curious about."
                    }
                },
                {
                    "hacking",
                    new List<string>()
                    {
                        "Cybersecurity is the practice of protecting systems, networks, and programs from digital attacks, commonly called cyberattacks or hacking.\n" +
                        "Think of cybersecurity as the digital version of superheroes who stop villains trying to rob banks — but in this case, the villains operate through the internet.\n" +
                        "These cyberattacks are usually aimed at accessing, modifying, or destroying sensitive information; extorting money through ransomware; or interrupting normal business processes.\n" +
                        "Effective cybersecurity techniques work best when they prevent damage before systems are even attacked, keeping everything running at 100%."
                    }
                },
                {
                    "hacked",
                    new List<string>()
                    {
                        "If you believe you have been exposed or potentially given away sensitive information, act quickly to protect your accounts.\n" +
                        "If an attacker gains access, they may lock YOU out of your own account.\n" +
                        "Steps to take:\n" +
                        "• Change your passwords immediately.\n" +
                        "• Sign out on all devices that have access to your account.\n" +
                        "• If banking information was compromised, block your cards and request replacements.\n" +
                        "This should limit the damage, but acting fast is key."
                    }
                },
                {
                    "what is hacking",
                    new List<string>()
                    {
                        "In simple terms, hacking is an illegal digital attack on systems. It is the very thing that cybersecurity works to fight against."
                    }
                },
                {
                    "password",
                    new List<string>()
                    {
                        "Use strong passwords that include numbers and symbols.",
                        "Never reuse passwords across multiple accounts.",
                        "A password manager can help you store and generate secure passwords safely."
                    }
                },
                {
                    "phishing",
                    new List<string>()
                    {
                        "Phishing is a tactic used by attackers to trick users into granting access to sensitive information.\n" +
                        "To protect yourself:\n" +
                        "• Never click suspicious email links.\n" +
                        "• Check the sender before opening attachments.\n" +
                        "• Phishing scams often create a false sense of urgency — slow down and verify."
                    }
                },
                {
                    "privacy",
                    new List<string>()
                    {
                        "Review your privacy settings regularly and read through any policy updates.",
                        "Avoid oversharing personal information online — once it's out there, it's hard to take back.",
                        "Enable two-factor authentication wherever possible for an extra layer of protection."
                    }
                },
                {
                    "scam",
                    new List<string>()
                    {
                        "Scammers often impersonate trusted companies.\n" +
                        "Never share OTPs (one-time passwords) with anyone — no legitimate company will ask for them.\n" +
                        "Always verify suspicious messages before acting on them."
                    }
                },
                {
                    "safe",
                    new List<string>()
                    {
                        "When you browse the internet, more can be happening in the background than you realise:\n" +
                        "• Your activity could be monitored by malicious software designed to steal passwords.\n" +
                        "• You could be tricked into clicking unsafe links that hand over your sensitive information.\n\n" +
                        "Here are key habits to stay safe:\n\n" +
                        "1. Be cautious with links — verify before you click. Use an online link checker if unsure.\n\n" +
                        "2. Use strong, unique passwords for every account. If one is compromised, others stay safe.\n\n" +
                        "3. Limit personal information you share online. Companies collect more data than most people realise.\n\n" +
                        "4. Recognise emotional manipulation — scams use urgency and fear to rush your decisions. Pause and think.\n\n" +
                        "5. Treat online safety as an ongoing habit, not a one-time setup. Threats evolve, and so should your awareness."
                    }
                }
            };
        }

        public string GetResponse(string input)
        {
            input = input.ToLower();

            if (string.IsNullOrWhiteSpace(memory.UserName))
            {
                memory.UserName = input;
                return $"Nice to meet you, {memory.UserName}! Ask me anything about cybersecurity.";
            }

            string sentiment = SentimentService.DetectSentiment(input);

            if (sentiment == "worried")
            {
                return "It's understandable to feel worried. Staying informed is one of the best defences. Be careful with suspicious links and messages.";
            }

            if (sentiment == "frustrated")
            {
                return "I understand your frustration. Cybersecurity issues can be annoying, but small habits make a huge difference.";
            }

            if (sentiment == "curious")
            {
                return "Curiosity is a great trait in cybersecurity. The more you learn, the safer you'll be online.";
            }

            foreach (var keyword in keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    memory.LastTopic = keyword;

                    if (keyword == "privacy")
                    {
                        memory.FavouriteTopic = "privacy";
                    }

                    var responses = keywordResponses[keyword];
                    return responses[random.Next(responses.Count)];
                }
            }

            if (input.Contains("another tip") ||
                input.Contains("tell me more") ||
                input.Contains("explain more"))
            {
                if (!string.IsNullOrWhiteSpace(memory.LastTopic) &&
                    keywordResponses.ContainsKey(memory.LastTopic))
                {
                    var responses = keywordResponses[memory.LastTopic];
                    return responses[random.Next(responses.Count)];
                }
            }

            if (input.Contains("how are you"))
            {
                return "I'm functioning perfectly and ready to help!";
            }

            if (input.Contains("your purpose"))
            {
                return "My purpose is to educate users about cybersecurity and help them stay safe online.";
            }

            if (input.Contains("what can i ask"))
            {
                return "You can ask me about passwords, scams, phishing, privacy, hacking, and how to stay safe online.";
            }

            if (!string.IsNullOrWhiteSpace(memory.FavouriteTopic))
            {
                return $"Since you're interested in {memory.FavouriteTopic}, remember to review your account security settings regularly.";
            }

            return "I didn't quite understand that. Could you try rephrasing? You can ask about passwords, phishing, scams, or privacy.";
        }
    }
}
