using System;
using System.Diagnostics;

namespace CyberSecurityChatBot.Services
{
    public static class VoiceService
    {
        public static void PlayGreeting()
        {
            // System.Media.SoundPlayer is not supported in OpenSilver/browser environments.
            // Audio playback would need to be handled via JavaScript interop if required.
            Debug.WriteLine("PlayGreeting: audio playback is not supported in this environment.");
        }
    }
}
