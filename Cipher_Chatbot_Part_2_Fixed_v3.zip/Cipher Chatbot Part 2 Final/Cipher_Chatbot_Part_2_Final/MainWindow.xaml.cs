using System.Windows;
using System.Windows.Input;
using CyberSecurityChatBot.Models;
using CyberSecurityChatBot.Services;

namespace CyberSecurityChatBot
{
    public partial class MainWindow : Window
    {
        private readonly ChatMemory memory = new ChatMemory();
        private ResponseService responseService;

        public MainWindow()
        {
            InitializeComponent();

            AsciiArtText.Text = AsciiArtService.GetArt();

            VoiceService.PlayGreeting();

            responseService = new ResponseService(memory);

            BotMessage("Hello There!");
            BotMessage("What is your name?");
        }

        private void UserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                SendButton_Click(sender, e);
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = UserInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Please enter a message.");
                return;
            }

            UserMessage(input);

            string response = responseService.GetResponse(input);
            BotMessage(response);

            // After name is set, add the welcome prompt once
            if (memory.UserName == input.ToLower() &&
                response.StartsWith("Nice to meet you"))
            {
                BotMessage("Ask me anything about cybersecurity.");
            }

            UserInput.Text = string.Empty;
        }

        private void ClearChat_Click(object sender, RoutedEventArgs e)
        {
            ChatArea.Text = string.Empty;
            BotMessage("Chat cleared.");
        }

        private void BotMessage(string message)
        {
            ChatArea.Text += $"\n[BOT]: {message}\n";
        }

        private void UserMessage(string message)
        {
            ChatArea.Text += $"\n[YOU]: {message}\n";
        }
    }
}
