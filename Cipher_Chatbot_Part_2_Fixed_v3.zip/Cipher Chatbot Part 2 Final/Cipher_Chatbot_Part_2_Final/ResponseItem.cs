using System.Collections.Generic;

namespace CyberSecurityChatBot.Models
{
    public class ResponseItem
    {
        public List<string> Responses { get; set; }
    }
}