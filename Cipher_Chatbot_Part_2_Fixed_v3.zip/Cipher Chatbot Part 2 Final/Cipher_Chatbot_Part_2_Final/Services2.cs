namespace CyberSecurityChatBot.Services
{
    public static class SentimentService
    {
        public static string DetectSentiment(string input)
        {
            input = input.ToLower();

            if (input.Contains("worried") || input.Contains("scared"))
            {
                return "worried";
            }

            if (input.Contains("frustrated") || input.Contains("angry"))
            {
                return "frustrated";
            }

            if (input.Contains("curious") || input.Contains("interested"))
            {
                return "curious";
            }

            return "neutral";
        }
    }
}