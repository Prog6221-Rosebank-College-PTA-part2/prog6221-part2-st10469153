namespace CyberSecurityChatBot.Services
{
    public static class AsciiArtService
    {
        public static string GetArt()
        {
            return @"                                              
          ██████ ██ ██████  ██   ██ ███████ ██████               
         ██      ██ ██   ██ ██   ██ ██      ██   ██              
         ██      ██ ██████  ███████ █████   ██████               
         ██      ██ ██      ██   ██ ██      ██   ██              
██ ██ ██  ██████ ██ ██      ██   ██ ███████ ██   ██ ██ ██ ██     
                                                                 
                                                                 ";
        }
    }
}