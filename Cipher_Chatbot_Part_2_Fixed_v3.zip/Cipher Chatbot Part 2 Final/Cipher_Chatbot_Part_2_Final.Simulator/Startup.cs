using OpenSilver.Simulator;
using System;

namespace Cipher_Chatbot_Part_2_Final.Simulator
{
    internal static class Startup
    {
        [STAThread]
        static int Main(string[] args)
        {
            return SimulatorLauncher.Start<App>();
        }
    }
}
